<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/estilos.css" title="Color">
    <title>Nueva Noticia</title>
</head>

<body>


    <main>

        <div class="box_nuevanoticia">
            <form action="XXXXXXXXX" method="post">

                <div>
                    <label for="titulo">Titulo:</label>
                    <input type="text" name="" value="">
                </div>

                <div>
                    <label for="cuerpo">Cuerpo:</label>

                    <textarea name="" rows="5">XXXXX</textarea>
                </div>

                <div>
                    <label for="autor">Autor:</label>
                    <input type="text" name="" value="">
                </div>

                <div>
                    <label for="fecha">Fecha:</label>
                    <input type="date" name="" value="">
                </div>

                <br>
                <div class="categorias">
                    <div><input type="radio" name="" value="">Sucesos</div>
                    <div><input type="radio" name="" value="" checked>Deportes</div>
                    <div><input type="radio" name="" value="">Corazón</div>
                </div>


                <div class="centrado">
                    <button type="submit" name="" value="">Crear noticia</button>
                </div>



            </form>
        </div>



    </main>
    <!-- BEGIN footer.php  -->

</body>

</html>