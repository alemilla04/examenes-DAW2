<?php

// CONSTANTES DEFINIDAS

define("BBDDFILE", 'data.json');


//Necesito el CURRENT WORKING DIRECTORY
//define('APP_FOLDER', substr(__DIR__, strlen($_SERVER['DOCUMENT_ROOT'])));
