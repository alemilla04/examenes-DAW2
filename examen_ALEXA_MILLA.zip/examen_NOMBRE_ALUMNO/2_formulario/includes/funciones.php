<?php


function obtenerListaNoticias()
{

    $bbddfile = BBDDFILE;
}



function añadirNoticia($nueva_noticia)
{

    $bbddfile = BBDDFILE;
}
