<header>
    <h1>EJERCICIO 1 - GESTOR DE NOTICIAS</h1>
</header>