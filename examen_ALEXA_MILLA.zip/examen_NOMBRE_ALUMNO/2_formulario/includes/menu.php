<nav>
  <ul>
    <li><a class="menu" href="index.php">Home</a></li>
    <li><a class="menu" href="nueva_noticia.php">Nueva Noticia</a></li>
  </ul>
  <br>
</nav>