<?php

//##################################################
//  API REST Employee.
//  Lista de endpoints
// 
//  - GET /                         Muestra la info de la API 
//  - GET /empleados                Todos los empleados
//  - GET /empleados/ciudad/Lorca       Empleados con direccion="Lorca"
//  - POST /empleados            Añadir un empleado
//  - DELETE /empleados/X        Borrar el empleado con ID=X
//  - DELETE /empleados/X-Y      Borrar los empleados desde ID=X hata ID=Y
//##################################################


header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
//header("Content-Type: text; charset=UTF-8");

header("Access-Control-Allow-Methods: OPTIONS,GET,POST,PUT,DELETE");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

//==== AYUDA Ejemplos de cabeceras de respuesta ======
//header("HTTP/1.1 404 Not Found");
//header("HTTP/1.1 200");
//header("HTTP/1.1 500 Internat Server Error");
//header("HTTP/1.1 201 Created");
//header("HTTP/1.1 204 No Content");

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = explode('/', $uri);
$requestMethod = $_SERVER["REQUEST_METHOD"];


//======== DEBUG ==========
// print_r($uri);
// exit();
//======== FIN DEBUG ==========


//===== ANALISIS DE URL ===========================


//===== FIN ANALISIS DE URL ===========================


switch ($requestMethod) {
    case 'GET':

        break;

    case 'POST':

        break;

    case 'DELETE':

        break;

    default:
        header("HTTP/1.1 404 Not Found");
        exit();
}
